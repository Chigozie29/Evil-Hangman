#ifndef STATUS_H
#define STATUS_H

enum boolean {FALSE, TRUE};
typedef enum boolean Boolean;

enum status {SUCCESS, FAILURE};
typedef enum status Status;

#endif
